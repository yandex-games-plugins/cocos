declare class GizmoConfig {
    static isIconGizmo3D: boolean;
    static iconGizmoSize: number;
}
export default GizmoConfig;
//# sourceMappingURL=gizmo-config.d.ts.map