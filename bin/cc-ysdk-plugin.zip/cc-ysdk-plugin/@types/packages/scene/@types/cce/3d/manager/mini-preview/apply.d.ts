import { renderer } from 'cc';
export declare function applyCamera(cameraComponent: any, camera?: renderer.scene.Camera | null): renderer.scene.Camera | null;
export declare function attachToScene(node: any, camera: any): void;
export declare function detachFromScene(camera: any): void;
//# sourceMappingURL=apply.d.ts.map