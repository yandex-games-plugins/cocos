export const PACKAGE_NAME = "yandex-games-sdk";

export const L10N_BUNDLE = {
  NAME: "ysdk-i18n-bundle",
  BUNDLE_PATH: "translations",
} as const;
