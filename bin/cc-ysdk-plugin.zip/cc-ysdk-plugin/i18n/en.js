"use strict";
module.exports = {
  "yandex-games-sdk": "Yandex.Games SDK",
  "localization-editor": "Localization Editor",
  "generate-templates": "Generate Templates",
  "check-templates": "Check Templates",
  description: "Official Yandex.Games SDK extension",
};
