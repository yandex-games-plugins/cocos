declare module "*.css" {
  const type: string;
  export default type;
}

declare module "*.scss" {
  const type: string;
  export default type;
}

declare module "*.sass" {
  const type: string;
  export default type;
}

declare module "*.html" {
  const type: string;
  export default type;
}
